for o in `docker ps -a | grep solr | awk  '{print $1}'` 
do
docker rm -f $o
done
 
